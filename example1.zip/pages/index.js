import Head from 'next/head'
import Meta from '../components/Meta'
import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <div classNameName={styles.container}>
      <Meta />

      <h1>Hello Donors</h1>
      <p>Ramadan Food supply for those who are fasting </p>
       <h2>Package1 750 bdt</h2>
       <div className="row">
    <div className="col s12 m6">
      <div className="card blue-grey darken-1">
        <div className="card-content white-text">
          <span className="card-title">Card Title</span>
          <p>I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively.</p>
        </div>
        <div className="card-action">
          <a href="#">This is a link</a>
          <a href="#">This is a link</a>
        </div>
      </div>
    </div>
  </div>
       <h2>Package2 1300 bdt</h2>
       <h1></h1>
    </div>
  )
}
