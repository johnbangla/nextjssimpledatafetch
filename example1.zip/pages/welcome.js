const welcome = () => {
  return (
    <div>
      Welcome Moon
    </div>
  )
}

export default welcome
